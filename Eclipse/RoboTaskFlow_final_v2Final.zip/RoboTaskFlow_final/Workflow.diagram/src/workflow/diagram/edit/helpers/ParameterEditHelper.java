/*
 * 
 */
package workflow.diagram.edit.helpers;

/**
 * @generated
 */
public class ParameterEditHelper extends WorkflowBaseEditHelper {
}
