/*
 * 
 */
package workflow.diagram.edit.helpers;

/**
 * @generated
 */
public class WorkflowEditHelper extends WorkflowBaseEditHelper {
}
