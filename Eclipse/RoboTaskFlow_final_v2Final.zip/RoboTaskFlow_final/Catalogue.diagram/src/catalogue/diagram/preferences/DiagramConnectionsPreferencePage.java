/*
 * 
 */
package catalogue.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.ConnectionsPreferencePage;

import catalogue.diagram.part.CatalogueDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramConnectionsPreferencePage extends ConnectionsPreferencePage {

	/**
	* @generated
	*/
	public DiagramConnectionsPreferencePage() {
		setPreferenceStore(CatalogueDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
