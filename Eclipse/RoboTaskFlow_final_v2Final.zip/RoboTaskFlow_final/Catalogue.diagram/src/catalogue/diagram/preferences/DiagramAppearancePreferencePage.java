/*
 * 
 */
package catalogue.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

import catalogue.diagram.part.CatalogueDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	* @generated
	*/
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(CatalogueDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
