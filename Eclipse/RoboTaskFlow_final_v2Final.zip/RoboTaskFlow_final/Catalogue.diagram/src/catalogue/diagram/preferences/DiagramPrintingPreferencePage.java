/*
 * 
 */
package catalogue.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;

import catalogue.diagram.part.CatalogueDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	* @generated
	*/
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(CatalogueDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
