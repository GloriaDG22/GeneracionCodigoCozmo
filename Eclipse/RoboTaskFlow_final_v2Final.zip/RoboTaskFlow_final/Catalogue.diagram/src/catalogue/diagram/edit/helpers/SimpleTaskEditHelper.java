/*
 * 
 */
package catalogue.diagram.edit.helpers;

/**
 * @generated
 */
public class SimpleTaskEditHelper extends CatalogueBaseEditHelper {
}
