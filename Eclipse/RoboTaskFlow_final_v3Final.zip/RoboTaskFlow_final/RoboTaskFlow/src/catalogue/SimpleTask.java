/**
 */
package catalogue;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple Task</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see catalogue.CataloguePackage#getSimpleTask()
 * @model annotation="gmf.node label='name' size='130,70' border.color='0,0,0'"
 * @generated
 */
public interface SimpleTask extends TaskDefinition {
} // SimpleTask
