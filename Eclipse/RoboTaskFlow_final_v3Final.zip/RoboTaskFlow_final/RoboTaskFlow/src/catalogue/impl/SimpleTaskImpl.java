/**
 */
package catalogue.impl;

import catalogue.CataloguePackage;
import catalogue.SimpleTask;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Simple Task</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SimpleTaskImpl extends TaskDefinitionImpl implements SimpleTask {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SimpleTaskImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return CataloguePackage.Literals.SIMPLE_TASK;
	}

} //SimpleTaskImpl
