/**
 */
package workflow.impl;

import org.eclipse.emf.ecore.EClass;

import workflow.Final;
import workflow.WorkflowPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Final</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class FinalImpl extends TaskImpl implements Final {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FinalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return WorkflowPackage.Literals.FINAL;
	}

} //FinalImpl
