/*
 * 
 */
package workflow.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

import workflow.diagram.part.WorkflowDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(WorkflowDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
