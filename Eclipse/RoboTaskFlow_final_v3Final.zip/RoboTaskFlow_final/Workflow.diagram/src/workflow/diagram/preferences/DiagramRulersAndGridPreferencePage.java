/*
 * 
 */
package workflow.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

import workflow.diagram.part.WorkflowDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	* @generated
	*/
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(WorkflowDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
