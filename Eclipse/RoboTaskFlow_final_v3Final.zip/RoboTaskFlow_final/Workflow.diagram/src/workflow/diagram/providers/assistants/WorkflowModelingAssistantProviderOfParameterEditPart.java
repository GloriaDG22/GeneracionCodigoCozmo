/*
 * 
 */
package workflow.diagram.providers.assistants;

import workflow.diagram.providers.WorkflowModelingAssistantProvider;

/**
 * @generated
 */
public class WorkflowModelingAssistantProviderOfParameterEditPart extends WorkflowModelingAssistantProvider {

}
