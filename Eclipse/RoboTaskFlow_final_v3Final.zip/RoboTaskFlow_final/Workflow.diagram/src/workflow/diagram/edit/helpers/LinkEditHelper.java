/*
 * 
 */
package workflow.diagram.edit.helpers;

/**
 * @generated
 */
public class LinkEditHelper extends WorkflowBaseEditHelper {
}
