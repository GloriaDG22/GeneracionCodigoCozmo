/*
 * 
 */
package workflow.diagram.edit.helpers;

/**
 * @generated
 */
public class InitialEditHelper extends WorkflowBaseEditHelper {
}
