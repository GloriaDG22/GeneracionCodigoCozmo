/*
 * 
 */
package workflow.diagram.edit.helpers;

/**
 * @generated
 */
public class FinalEditHelper extends WorkflowBaseEditHelper {
}
