/*
 * 
 */
package workflow.diagram.edit.helpers;

/**
 * @generated
 */
public class ActivityEditHelper extends WorkflowBaseEditHelper {
}
