/*
 * 
 */
package workflow.diagram.edit.helpers;

/**
 * @generated
 */
public class QuestionEditHelper extends WorkflowBaseEditHelper {
}
