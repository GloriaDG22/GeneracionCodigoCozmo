/*
* 
*/
package workflow.diagram.edit.policies;

import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.commands.core.commands.DuplicateEObjectsCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.DuplicateElementsRequest;

import workflow.diagram.edit.commands.ActivityCreateCommand;
import workflow.diagram.edit.commands.AnswerCreateCommand;
import workflow.diagram.edit.commands.FinalCreateCommand;
import workflow.diagram.edit.commands.InitialCreateCommand;
import workflow.diagram.edit.commands.LoopCreateCommand;
import workflow.diagram.edit.commands.QuestionCreateCommand;
import workflow.diagram.providers.WorkflowElementTypes;

/**
 * @generated
 */
public class WorkflowItemSemanticEditPolicy extends WorkflowBaseItemSemanticEditPolicy {

	/**
	* @generated
	*/
	public WorkflowItemSemanticEditPolicy() {
		super(WorkflowElementTypes.Workflow_1000);
	}

	/**
	* @generated
	*/
	protected Command getCreateCommand(CreateElementRequest req) {
		if (WorkflowElementTypes.Loop_2001 == req.getElementType()) {
			return getGEFWrapper(new LoopCreateCommand(req));
		}
		if (WorkflowElementTypes.Activity_2002 == req.getElementType()) {
			return getGEFWrapper(new ActivityCreateCommand(req));
		}
		if (WorkflowElementTypes.Initial_2003 == req.getElementType()) {
			return getGEFWrapper(new InitialCreateCommand(req));
		}
		if (WorkflowElementTypes.Final_2004 == req.getElementType()) {
			return getGEFWrapper(new FinalCreateCommand(req));
		}
		if (WorkflowElementTypes.Question_2005 == req.getElementType()) {
			return getGEFWrapper(new QuestionCreateCommand(req));
		}
		if (WorkflowElementTypes.Answer_2006 == req.getElementType()) {
			return getGEFWrapper(new AnswerCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

	/**
	* @generated
	*/
	protected Command getDuplicateCommand(DuplicateElementsRequest req) {
		TransactionalEditingDomain editingDomain = ((IGraphicalEditPart) getHost()).getEditingDomain();
		return getGEFWrapper(new DuplicateAnythingCommand(editingDomain, req));
	}

	/**
	* @generated
	*/
	private static class DuplicateAnythingCommand extends DuplicateEObjectsCommand {

		/**
		* @generated
		*/
		public DuplicateAnythingCommand(TransactionalEditingDomain editingDomain, DuplicateElementsRequest req) {
			super(editingDomain, req.getLabel(), req.getElementsToBeDuplicated(), req.getAllDuplicatedElementsMap());
		}

	}

}
