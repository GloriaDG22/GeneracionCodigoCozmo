/*
 * 
 */
package workflow.diagram.edit.helpers;

/**
 * @generated
 */
public class LoopEditHelper extends WorkflowBaseEditHelper {
}
