/*
 * 
 */
package catalogue.diagram.providers.assistants;

import catalogue.diagram.providers.CatalogueModelingAssistantProvider;

/**
 * @generated
 */
public class CatalogueModelingAssistantProviderOfParameterDefinitionEditPart
		extends CatalogueModelingAssistantProvider {

}
