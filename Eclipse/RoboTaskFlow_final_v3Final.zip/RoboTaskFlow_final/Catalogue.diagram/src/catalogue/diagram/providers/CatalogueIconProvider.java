/*
 * 
 */
package catalogue.diagram.providers;

import org.eclipse.gmf.runtime.common.ui.services.icon.IIconProvider;
import org.eclipse.gmf.tooling.runtime.providers.DefaultElementTypeIconProvider;

/**
 * @generated
 */
public class CatalogueIconProvider extends DefaultElementTypeIconProvider implements IIconProvider {

	/**
	* @generated
	*/
	public CatalogueIconProvider() {
		super(CatalogueElementTypes.TYPED_INSTANCE);
	}

}
