/*
 * 
 */
package catalogue.diagram.edit.helpers;

/**
 * @generated
 */
public class ParameterDefinitionEditHelper extends CatalogueBaseEditHelper {
}
