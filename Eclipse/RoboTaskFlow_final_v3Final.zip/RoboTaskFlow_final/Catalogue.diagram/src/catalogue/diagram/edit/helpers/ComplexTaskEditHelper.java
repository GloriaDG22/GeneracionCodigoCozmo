/*
 * 
 */
package catalogue.diagram.edit.helpers;

/**
 * @generated
 */
public class ComplexTaskEditHelper extends CatalogueBaseEditHelper {
}
