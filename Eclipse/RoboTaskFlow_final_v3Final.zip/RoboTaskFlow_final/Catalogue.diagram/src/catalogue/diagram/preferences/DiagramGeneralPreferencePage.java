/*
 * 
 */
package catalogue.diagram.preferences;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

import catalogue.diagram.part.CatalogueDiagramEditorPlugin;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	* @generated
	*/
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(CatalogueDiagramEditorPlugin.getInstance().getPreferenceStore());
	}
}
